import express from "express"
const app = express ()
app.listen (3000, () =>{console.log("servidor")})

app.get("/", (req,res) => {res.send("Hola amiguitos")})